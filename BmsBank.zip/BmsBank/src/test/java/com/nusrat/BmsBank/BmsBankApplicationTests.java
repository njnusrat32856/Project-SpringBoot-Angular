package com.nusrat.BmsBank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BmsBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
