package com.nusrat.BmsBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BmsBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(BmsBankApplication.class, args);
	}

}
