import { User } from "./user.model";

export class Token {
    
    id!: number;
    token!: string;
    user!: User;
  
    
  }