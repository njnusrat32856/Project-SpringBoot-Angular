package com.nusrat.BmsBank.entity;

public enum TransactionType {

    DEPOSIT,
    WITHDRAW,
    FUND_TRANSFER
//    TRANSFER
}
