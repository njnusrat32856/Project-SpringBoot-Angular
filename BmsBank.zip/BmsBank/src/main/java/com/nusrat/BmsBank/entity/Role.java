package com.nusrat.BmsBank.entity;

public enum Role {

    USER,
    ADMIN
}
