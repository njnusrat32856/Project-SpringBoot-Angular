
export class User {

    id !: number;
    accountNumber !: string;
    firstName !: string;
    lastName !: string;
    email !: string;
    password !: string;
    gender !: string;
    address !: string;
    mobileNo !: string;
    nid !: string;
    dob !: string;
    image !: string;
    accountType !: string;
    createDate !: string;
    status !: boolean;
    balance !: number;

}
