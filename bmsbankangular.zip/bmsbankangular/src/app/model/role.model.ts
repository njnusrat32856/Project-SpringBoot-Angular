export enum Role {
    
    ADMIN,
    USER
  }